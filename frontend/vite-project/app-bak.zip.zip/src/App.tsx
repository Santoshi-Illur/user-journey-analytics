// src/App.tsx
import React, { useState } from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import LoginPage from "./pages/LoginPage";
import Layout from "./components/Layout";
import DashboardPage from "./pages/DashboardPage";
import UserJourneyPage from "./pages/UserJourneyPage";
import FunnelPage from "./pages/FunnelAnalysisPage";

const App: React.FC = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  const handleLogin = () => {
    setIsLoggedIn(true);
  };

  return (
    <Routes>
      {/* Login Page */}
      <Route
        path="/"
        element={
          !isLoggedIn ? (
            <LoginPage onLogin={handleLogin} />
          ) : (
            <Navigate to="/app/dashboard" replace />
          )
        }
      />

      {/* Protected Routes under Layout */}
      <Route path="/app" element={isLoggedIn ? <Layout /> : <Navigate to="/" replace />}>
        <Route path="dashboard" element={<DashboardPage />} />
        <Route path="user/:id" element={<UserJourneyPage />} />
        <Route path="funnel" element={<FunnelPage />} />
        {/* Default redirect under /app */}
        <Route path="" element={<Navigate to="dashboard" replace />} />
      </Route>

      {/* Fallback route */}
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
};

export default App;
