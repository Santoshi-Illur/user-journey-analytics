// src/pages/UserJourneyPage.tsx
import React, { useMemo, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import {
  Box,
  Typography,
  Card,
  CardContent,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Button,
  Grid,
} from "@mui/material";

import dayjs, { Dayjs } from "dayjs";
import { DatePicker, LocalizationProvider } from "@mui/x-date-pickers";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";

import { Line, Bar } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  PointElement,
  LineElement,
  Tooltip,
  Legend,
} from "chart.js";

import userJourneyData from "../data/user-journey-data.json";

ChartJS.register(CategoryScale, LinearScale, BarElement, PointElement, LineElement, Tooltip, Legend);

export default function UserJourneyPage(): JSX.Element {
  const { id } = useParams();
  const navigate = useNavigate();

  const user = useMemo(() => userJourneyData.find((u: any) => String(u.userId) === String(id)), [id]);

  const [startDate, setStartDate] = useState<Dayjs | null>(dayjs().subtract(30, "day"));
  const [endDate, setEndDate] = useState<Dayjs | null>(dayjs());

  if (!user) {
    return (
      <Box p={3}>
        <Typography>User not found</Typography>
      </Box>
    );
  }

  // Filter events by the date range (events have time; base on session date)
  const filteredEvents = useMemo(() => {
    const baseDate = (user.sessionStart || "").split(" ")[0] || dayjs().format("YYYY-MM-DD");
    return (user.events || []).filter((ev: any) => {
      const eventDate = dayjs(`${baseDate} ${ev.time}`, ["YYYY-MM-DD HH:mm", "YYYY-MM-DDTHH:mm"]);
      const startOk = !startDate || eventDate.isAfter(startDate.subtract(1, "day"));
      const endOk = !endDate || eventDate.isBefore(endDate.add(1, "day"));
      return startOk && endOk;
    });
  }, [user, startDate, endDate]);

  // Chart datasets
  const labels = filteredEvents.map((e: any) => e.time || "");

  const pagesSeries = filteredEvents.map((e: any) => e.pagesVisited ?? 1);
  const purchaseSeries = filteredEvents.map((e: any) => (e.event === "Purchase" ? 1 : 0));
  const timeSeries = filteredEvents.map((e: any) => e.duration ?? 0);

  // Session timeline (line)
  const sessionData = {
    labels,
    datasets: [
      {
        label: "Events",
        data: filteredEvents.map((_e: any, i: number) => i + 1),
        borderColor: "#1976d2",
        backgroundColor: "rgba(25,118,210,0.15)",
        tension: 0.35,
        fill: true,
      },
    ],
  };

  // small charts
  const smallOptions = {
    maintainAspectRatio: false as const,
    plugins: { legend: { display: false } },
    scales: { x: { display: false }, y: { display: false } },
  };

  const pagesChartData = { labels, datasets: [{ data: pagesSeries, backgroundColor: "#1976d2" }] };
  const purchaseChartData = { labels, datasets: [{ data: purchaseSeries, backgroundColor: "#7B1FA2" }] };
  const timeChartData = { labels, datasets: [{ data: timeSeries, backgroundColor: "#FB8C00" }] };

  // Event trend (larger full-width)
  const eventTrendData = {
    labels,
    datasets: [
      {
        label: "Event trend",
        data: filteredEvents.map((_e: any, i: number) => i + 1),
        borderColor: "#1976d2",
        backgroundColor: "rgba(25,118,210,0.12)",
        tension: 0.35,
        fill: true,
      },
    ],
  };

  const eventTrendOptions = {
    maintainAspectRatio: false as const,
    plugins: { legend: { display: false } },
    scales: { x: { ticks: { maxRotation: 45, minRotation: 45 } } },
    responsive: true,
  };

  return (
    <LocalizationProvider dateAdapter={AdapterDayjs}>
      <Box p={3}>
        <Stack direction="row" justifyContent="space-between" alignItems="center" mb={3}>
          <Typography variant="h4" fontWeight={700}>
            User Journey — {user.name}
          </Typography>
          <Button 
  variant="contained" 
  onClick={() => navigate("/app/dashboard")}
>
  Back to Dashboard
</Button>

        </Stack>

        {/* Top small charts replacing KPI tiles */}
        <Grid container spacing={2} mb={3}>
          <Grid item xs={12} sm={6} md={3}>
            <Card sx={{ p: 1 }}>
              <CardContent sx={{ p: 1 }}>
                <Typography variant="subtitle2" color="text.secondary">
                  Session Start
                </Typography>
                <Typography variant="h6" fontWeight={800}>
                  {user.sessionStart}
                </Typography>
                <Box sx={{ height: 90, mt: 1 }}>
                  <Line data={sessionData} options={smallOptions} />
                </Box>
              </CardContent>
            </Card>
          </Grid>

          <Grid item xs={12} sm={6} md={3}>
            <Card sx={{ p: 1 }}>
              <CardContent sx={{ p: 1 }}>
                <Typography variant="subtitle2" color="text.secondary">
                  Pages Visited
                </Typography>
                <Typography variant="h6" fontWeight={800}>
                  {user.pagesVisited}
                </Typography>
                <Box sx={{ height: 90, mt: 1 }}>
                  <Bar data={pagesChartData} options={smallOptions} />
                </Box>
              </CardContent>
            </Card>
          </Grid>

          <Grid item xs={12} sm={6} md={3}>
            <Card sx={{ p: 1 }}>
              <CardContent sx={{ p: 1 }}>
                <Typography variant="subtitle2" color="text.secondary">
                  Purchases
                </Typography>
                <Typography variant="h6" fontWeight={800}>
                  {user.purchaseCount}
                </Typography>
                <Box sx={{ height: 90, mt: 1 }}>
                  <Bar data={purchaseChartData} options={smallOptions} />
                </Box>
              </CardContent>
            </Card>
          </Grid>

          <Grid item xs={12} sm={6} md={3}>
            <Card sx={{ p: 1 }}>
              <CardContent sx={{ p: 1 }}>
                <Typography variant="subtitle2" color="text.secondary">
                  Time Spent (min)
                </Typography>
                <Typography variant="h6" fontWeight={800}>
                  {user.timeOnPage}
                </Typography>
                <Box sx={{ height: 90, mt: 1 }}>
                  <Bar data={timeChartData} options={smallOptions} />
                </Box>
              </CardContent>
            </Card>
          </Grid>
        </Grid>

        {/* Date filter */}
        <Stack direction="row" spacing={2} mb={3} alignItems="center">
          <DatePicker label="Start Date" value={startDate} onChange={(v: any) => setStartDate(v)} />
          <DatePicker label="End Date" value={endDate} onChange={(v: any) => setEndDate(v)} />
          <Button
            variant="outlined"
            onClick={() => {
              setStartDate(dayjs().subtract(30, "day"));
              setEndDate(dayjs());
            }}
          >
            Clear
          </Button>
        </Stack>

        {/* Event trend (full-width) */}
        <Card sx={{ mb: 2 }}>
          <CardContent>
            <Typography variant="h6" mb={2}>
              Event Trend
            </Typography>
            <Box sx={{ height: 300 }}>
              <Line data={eventTrendData} options={eventTrendOptions} />
            </Box>
          </CardContent>
        </Card>

        {/* Event table (below) */}
        <Card>
          <CardContent>
            <Typography variant="h6" mb={2}>
              Event Details
            </Typography>
            <TableContainer component={Paper}>
              <Table stickyHeader>
                <TableHead>
                  <TableRow>
                    <TableCell>Event</TableCell>
                    <TableCell>Page</TableCell>
                    <TableCell>Time</TableCell>
                    <TableCell align="right">Duration (min)</TableCell>
                  </TableRow>
                </TableHead>

                <TableBody>
                  {filteredEvents.map((ev: any, i: number) => (
                    <TableRow key={i}>
                      <TableCell>{ev.event}</TableCell>
                      <TableCell>{ev.page}</TableCell>
                      <TableCell>{ev.time}</TableCell>
                      <TableCell align="right">{ev.duration}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          </CardContent>
        </Card>
      </Box>
    </LocalizationProvider>
  );
}
