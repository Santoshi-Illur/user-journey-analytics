// src/pages/DashboardPage.tsx
import React, { useMemo, useState } from "react";
import {
  Box,
  Typography,
  Card,
  CardContent,
  Stack,
  Grid,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  IconButton,
  Button,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TablePagination,
} from "@mui/material";

import ClearIcon from "@mui/icons-material/Clear";
import VisibilityIcon from "@mui/icons-material/Visibility";

import { useNavigate } from "react-router-dom";
import dayjs, { Dayjs } from "dayjs";

import DateRangeSelector from "../components/DateRangeSelector";
import userJourneyData from "../data/user-journey-data.json";

// charts
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
} from "chart.js";
import { Bar, Line } from "react-chartjs-2";

ChartJS.register(CategoryScale, LinearScale, BarElement, PointElement, LineElement, Title, Tooltip, Legend);

// --- Types
type UserRecord = {
  userId: number;
  name: string;
  email: string;
  sessionStart: string;
  pagesVisited: number;
  purchaseCount: number;
  timeOnPage: number;
  device?: string;
  country?: string;
  events?: Array<{ event: string; page: string; time: string; duration: number }>;
};

const SPARK_N = 8; // show last N points in sparklines

export default function DashboardPage(): JSX.Element {
  const navigate = useNavigate();

  // Filters
  const [search, setSearch] = useState<string>("");
  const [device, setDevice] = useState<string>("");
  const [country, setCountry] = useState<string>("");
  const [eventType, setEventType] = useState<string>("");

  // Date range default last 30 days
  const [startDate, setStartDate] = useState<Dayjs | null>(dayjs().subtract(30, "day"));
  const [endDate, setEndDate] = useState<Dayjs | null>(dayjs());

  // Pagination
  const [page, setPage] = useState<number>(0);
  const rowsPerPage = 10;

  // Static options
  const deviceOptions = ["Desktop", "Mobile", "Tablet"];
  const countryOptions = ["India", "USA", "UK", "Germany"];
  const eventOptions = ["Page Visit", "Search", "Add to Cart", "Purchase"];

  const parseSessionDate = (s?: string) => {
    if (!s) return dayjs(NaN);
    const normalized = s.includes(" ") ? s.replace(" ", "T") : s;
    return dayjs(normalized, ["YYYY-MM-DDTHH:mm", "YYYY-MM-DD HH:mm", "YYYY-MM-DD"], true);
  };

  // filtered users (memoized)
  const filteredUsers = useMemo(() => {
    const q = search.trim().toLowerCase();
    const arr = (userJourneyData as UserRecord[]).filter((u) => {
      const matchesSearch =
        q === "" ||
        (u.name && u.name.toLowerCase().includes(q)) ||
        (u.email && u.email.toLowerCase().includes(q));
      const matchesDevice = !device || u.device === device;
      const matchesCountry = !country || u.country === country;
      const matchesEvent =
        !eventType || (u.events && u.events.some((ev) => (ev.event || "").toLowerCase() === eventType.toLowerCase()));

      const sd = parseSessionDate(u.sessionStart);
      const startOk = !startDate || (sd.isValid() && !sd.isBefore(startDate, "day"));
      const endOk = !endDate || (sd.isValid() && !sd.isAfter(endDate, "day"));

      return matchesSearch && matchesDevice && matchesCountry && matchesEvent && startOk && endOk;
    });

    // newest first
    arr.sort((a, b) => parseSessionDate(b.sessionStart).valueOf() - parseSessionDate(a.sessionStart).valueOf());
    return arr;
  }, [search, device, country, eventType, startDate, endDate]);

  // KPI aggregates
  const totalPages = filteredUsers.reduce((acc, u) => acc + (Number(u.pagesVisited) || 0), 0);
  const totalPurchases = filteredUsers.reduce((acc, u) => acc + (Number(u.purchaseCount) || 0), 0);
  const totalTime = filteredUsers.reduce((acc, u) => acc + (Number(u.timeOnPage) || 0), 0);
  const sessionsCount = filteredUsers.length;

  const clearFilters = () => {
    setSearch("");
    setDevice("");
    setCountry("");
    setEventType("");
    setStartDate(dayjs().subtract(30, "day"));
    setEndDate(dayjs());
    setPage(0);
  };

  const handleChangePage = (_: unknown, newPage: number) => {
    setPage(newPage);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  // sparkline helpers
  const labelsForSpark = (arr: UserRecord[]) => {
    const slice = arr.slice(0, SPARK_N);
    return slice.map((u) => u.name.split(" ")[0] || "user");
  };

  const metricVals = (arr: UserRecord[], metric: keyof UserRecord) => {
    const slice = arr.slice(0, SPARK_N);
    return slice.map((u) => Number((u as any)[metric]) || 0);
  };

  // Create chart data for a mini-sparkline (bar)
  const makeSparkBar = (arr: UserRecord[], metric: keyof UserRecord, color: string) => {
    const labels = labelsForSpark(arr);
    const data = metricVals(arr, metric);
    return {
      labels,
      datasets: [
        {
          data,
          backgroundColor: color,
          barPercentage: 0.9,
          categoryPercentage: 0.9,
        },
      ],
    };
  };

  const miniOptions = {
    responsive: true,
    maintainAspectRatio: false as const,
    plugins: { legend: { display: false } },
    scales: {
      x: { display: false },
      y: { display: false },
    },
  };

  // colors (multi-color option)
  const BLUE = "#1976d2";
  const PURPLE = "#7B1FA2";
  const ORANGE = "#FB8C00";
  const TEAL = "#00796B";

  const pagesChart = makeSparkBar(filteredUsers, "pagesVisited", BLUE);
  const purchasesChart = makeSparkBar(filteredUsers, "purchaseCount", PURPLE);
  const timeChart = makeSparkBar(filteredUsers, "timeOnPage", ORANGE);
  const sessionsChart = makeSparkBar(filteredUsers, "pagesVisited", TEAL); // sessions simple

  return (
    <Box sx={{ p: { xs: 2, md: 4 }, maxWidth: 1200, mx: "auto" }}>
      {/* header */}
      <Stack direction="row" justifyContent="space-between" alignItems="center" mb={3}>
        <Typography variant="h4" fontWeight={700}>
          Dashboard
        </Typography>
        <Button
  variant="outlined"
  size="small"
  onClick={() => navigate("/app/funnel")}>
  View Funnel
</Button>

      </Stack>

      {/* Filters */}
      <Card sx={{ mb: 3, p: 2, borderRadius: 2 }}>
        <Stack spacing={2}>
          <Stack direction="row" spacing={2} alignItems="center" sx={{ width: "100%", justifyContent: "space-between", flexWrap: "nowrap" }}>
            <TextField size="small" placeholder="Search by name or email" value={search} onChange={(e) => setSearch(e.target.value)} sx={{ flex: 1, minWidth: 220, maxWidth: 360 }} />

            <FormControl size="small" sx={{ minWidth: 140, flex: "0 0 140px" }}>
              <InputLabel>Device</InputLabel>
              <Select value={device} label="Device" onChange={(e) => setDevice(e.target.value)}>
                <MenuItem value="">All</MenuItem>
                {deviceOptions.map((d) => (
                  <MenuItem key={d} value={d}>
                    {d}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>

            <FormControl size="small" sx={{ minWidth: 140, flex: "0 0 140px" }}>
              <InputLabel>Country</InputLabel>
              <Select value={country} label="Country" onChange={(e) => setCountry(e.target.value)}>
                <MenuItem value="">All</MenuItem>
                {countryOptions.map((c) => (
                  <MenuItem key={c} value={c}>
                    {c}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>

            <FormControl size="small" sx={{ minWidth: 160, flex: "0 0 160px" }}>
              <InputLabel>Event</InputLabel>
              <Select value={eventType} label="Event" onChange={(e) => setEventType(e.target.value)}>
                <MenuItem value="">All</MenuItem>
                {eventOptions.map((ev) => (
                  <MenuItem key={ev} value={ev}>
                    {ev}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          </Stack>

          <Stack direction="row" spacing={2} alignItems="center">
            <DateRangeSelector
              value={{ start: startDate, end: endDate }}
              onChange={(range: { start: Dayjs | null; end: Dayjs | null }) => {
                setStartDate(range.start);
                setEndDate(range.end);
              }}
            />
            <IconButton onClick={clearFilters} color="error" aria-label="clear-filters">
              <ClearIcon />
            </IconButton>
            <Box sx={{ flex: 1 }} />
          </Stack>
        </Stack>
      </Card>

      {/* KPI sparklines */}
      <Grid container spacing={2} mb={3}>
        <Grid item xs={12} sm={6} md={3}>
          <Card sx={{ p: 1 }}>
            <CardContent sx={{ p: 1 }}>
              <Typography variant="subtitle2" color="text.secondary">
                Pages Visited
              </Typography>
              <Typography variant="h6" fontWeight={700}>
                {totalPages}
              </Typography>
              <Box sx={{ height: 72, mt: 1 }}>
                <Bar data={pagesChart} options={miniOptions} />
              </Box>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} sm={6} md={3}>
          <Card sx={{ p: 1 }}>
            <CardContent sx={{ p: 1 }}>
              <Typography variant="subtitle2" color="text.secondary">
                Purchases
              </Typography>
              <Typography variant="h6" fontWeight={700}>
                {totalPurchases}
              </Typography>
              <Box sx={{ height: 72, mt: 1 }}>
                <Bar data={purchasesChart} options={miniOptions} />
              </Box>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} sm={6} md={3}>
          <Card sx={{ p: 1 }}>
            <CardContent sx={{ p: 1 }}>
              <Typography variant="subtitle2" color="text.secondary">
                Time Spent (min)
              </Typography>
              <Typography variant="h6" fontWeight={700}>
                {totalTime}
              </Typography>
              <Box sx={{ height: 72, mt: 1 }}>
                <Bar data={timeChart} options={miniOptions} />
              </Box>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} sm={6} md={3}>
          <Card sx={{ p: 1 }}>
            <CardContent sx={{ p: 1 }}>
              <Typography variant="subtitle2" color="text.secondary">
                Sessions
              </Typography>
              <Typography variant="h6" fontWeight={700}>
                {sessionsCount}
              </Typography>
              <Box sx={{ height: 72, mt: 1 }}>
                <Bar data={sessionsChart} options={miniOptions} />
              </Box>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Users Table */}
      <Card>
        <CardContent sx={{ p: 0 }}>
          <Box sx={{ px: 3, py: 2 }}>
            <Typography variant="h6">Users Overview — {filteredUsers.length} results</Typography>
          </Box>

          <TableContainer component={Paper}>
            <Table stickyHeader>
              <TableHead>
                <TableRow>
                  <TableCell>Name / Email</TableCell>
                  <TableCell>Device</TableCell>
                  <TableCell>Country</TableCell>
                  <TableCell>Session Start</TableCell>
                  <TableCell align="right">Pages</TableCell>
                  <TableCell align="right">Purchases</TableCell>
                  <TableCell align="right">Time (min)</TableCell>
                  <TableCell align="center">Action</TableCell>
                </TableRow>
              </TableHead>

              <TableBody>
                {filteredUsers.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).map((u) => (
                  <TableRow key={u.userId} hover>
                    <TableCell>
                      <Typography fontWeight={700}>{u.name}</Typography>
                      <Typography variant="body2" color="text.secondary">
                        {u.email}
                      </Typography>
                    </TableCell>

                    <TableCell>{u.device ?? "—"}</TableCell>
                    <TableCell>{u.country ?? "—"}</TableCell>

                    <TableCell>
                      {parseSessionDate(u.sessionStart).isValid()
                        ? parseSessionDate(u.sessionStart).format("MMM D, YYYY HH:mm")
                        : u.sessionStart}
                    </TableCell>

                    <TableCell align="right">{u.pagesVisited}</TableCell>
                    <TableCell align="right">{u.purchaseCount}</TableCell>
                    <TableCell align="right">{u.timeOnPage}</TableCell>

                    <TableCell align="center">
                      <Button
  variant="contained"
  size="small"
  onClick={() => navigate(`/app/user/${u.userId}`)}
>
  View Journey
</Button>

                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>

          <Box sx={{ display: "flex", justifyContent: "flex-end", p: 2 }}>
            <TablePagination component="div" count={filteredUsers.length} page={page} onPageChange={handleChangePage} rowsPerPage={rowsPerPage} rowsPerPageOptions={[rowsPerPage]} />
          </Box>
        </CardContent>
      </Card>
    </Box>
  );
}
