import React from "react";
import { Box, Typography, Card, CardContent } from "@mui/material";
import { Bar } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Tooltip,
  Legend,
} from "chart.js";
import { useNavigate } from "react-router-dom";


ChartJS.register(CategoryScale, LinearScale, BarElement, Tooltip, Legend);

const funnelStages = [
  { stage: "Visited Website", count: 1000 },
  { stage: "Viewed Product", count: 720 },
  { stage: "Added to Cart", count: 340 },
  { stage: "Checkout Started", count: 180 },
  { stage: "Purchase Completed", count: 95 },
];

export default function FunnelPage() {
  const navigate = useNavigate();
  const data = {
    labels: funnelStages.map((s) => s.stage),
    datasets: [
      {
        label: "Users",
        data: funnelStages.map((s) => s.count),
        backgroundColor: [
          "#4a90e2",
          "#50b7c1",
          "#7bc67e",
          "#f5a623",
          "#d0021b",
        ],
        borderRadius: 6,
        barThickness: 30,
      },
    ],
  };

  const options = {
    indexAxis: "y" as const,
    responsive: true,
    plugins: {
      legend: { display: false },
      tooltip: {
        callbacks: {
          label: (ctx: any) => `Users: ${ctx.raw}`,
        },
      },
    },
    scales: {
      x: { beginAtZero: true },
    },
  };

  return (
    <Box p={3}>
      <Typography variant="h4" mb={3}>
        Funnel Analysis
      </Typography>

      <Card>
        <CardContent>
          <Typography variant="h6" mb={2}>
            Conversion Funnel
          </Typography>
          <Bar data={data} options={options} />
        </CardContent>
      </Card>
    </Box>
  );
}
