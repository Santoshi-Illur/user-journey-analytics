// src/features/dashboard/dashboardApi.ts
import { api } from "../../app/api";

export const dashboardApi = api.injectEndpoints({
  endpoints: (build) => ({
    getDashboard: build.query<any, { start?: string; end?: string; device?: string; country?: string; eventType?: string; q?: string; page?: number; limit?: number }>({
      query: (params) => ({ url: "/dashboard", params }),
      providesTags: (result) => result ? [{ type: "Dashboard", id: "LIST" }] : [{ type: "Dashboard", id: "LIST" }]
    }),
    getDashboardCharts: build.query<any, { start?: string; end?: string }>({
      query: (params) => ({ url: "/dashboard/charts", params }),
      providesTags: [{ type: "Dashboard", id: "Charts" }]
    })
  }),
  overrideExisting: false
});

export const { useGetDashboardQuery, useGetDashboardChartsQuery } = dashboardApi;
