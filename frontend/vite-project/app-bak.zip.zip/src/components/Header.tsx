import { AppBar, Toolbar, Typography } from "@mui/material";

export default function Header() {
  return (
    <AppBar position="fixed" elevation={1} sx={{ background: "#1976d2" }}>
      <Toolbar>
        <Typography variant="h6" fontWeight={600}>
          User Journey Analytics
        </Typography>
      </Toolbar>
    </AppBar>
  );
}
