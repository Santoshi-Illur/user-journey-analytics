import React, { useState } from "react";
import {
  Box,
  Popover,
  TextField,
  Stack,
  IconButton,
} from "@mui/material";
import { DatePicker, LocalizationProvider } from "@mui/x-date-pickers";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import CalendarMonthIcon from "@mui/icons-material/CalendarMonth";
import ClearIcon from "@mui/icons-material/Clear";
import dayjs, { Dayjs } from "dayjs";

interface Props {
  value: { start: Dayjs | null; end: Dayjs | null };
  onChange: (range: { start: Dayjs | null; end: Dayjs | null }) => void;
}

export default function DateRangeSelector({ value, onChange }: Props) {
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);

  const open = Boolean(anchorEl);

  const handleOpen = (e: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(e.currentTarget);
  };

  const handleClose = () => setAnchorEl(null);

  const displayValue =
    value.start && value.end
      ? `${value.start.format("DD MMM YYYY")} - ${value.end.format("DD MMM YYYY")}`
      : "";

  return (
    <LocalizationProvider dateAdapter={AdapterDayjs}>
      <Box display="flex" alignItems="center" gap={1}>
        {/* DATE RANGE INPUT */}
        <TextField
          size="small"
          label="Date Range"
          value={displayValue}
          onClick={handleOpen}
          sx={{ width: 250 }}
          InputProps={{
            endAdornment: (
              <IconButton size="small" onClick={handleOpen}>
                <CalendarMonthIcon fontSize="small" />
              </IconButton>
            ),
          }}
        />

        {/* CLEAR BUTTON */}
        <IconButton
          onClick={() => onChange({ start: null, end: null })}
          size="small"
        >
          <ClearIcon fontSize="small" />
        </IconButton>

        {/* POPOVER WITH TWO CALENDARS */}
        <Popover
          open={open}
          anchorEl={anchorEl}
          onClose={handleClose}
          anchorOrigin={{ vertical: "bottom", horizontal: "left" }}
          transformOrigin={{ vertical: "top", horizontal: "left" }}
        >
          <Box p={2} sx={{ background: "#fff" }}>
            <Stack direction="row" spacing={2}>
              <DatePicker
                label="Start Date"
                value={value.start}
                onChange={(newValue) =>
                  onChange({ start: newValue, end: value.end })
                }
              />

              <DatePicker
                label="End Date"
                value={value.end}
                onChange={(newValue) =>
                  onChange({ start: value.start, end: newValue })
                }
              />
            </Stack>
          </Box>
        </Popover>
      </Box>
    </LocalizationProvider>
  );
}
